// C Program to demonstrate it
// doesn't support Name Mangling

int printf(const char* format, ...);

// Driver Code
int main()
{
    printf("Hello World.\n");
    return 0;
}
