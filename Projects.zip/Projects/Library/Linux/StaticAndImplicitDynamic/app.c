#include <stdio.h>
#include "mathlib.h"

int main (int argc, char *argv[])
{
    int result;
    result = add(1, 2);
    printf ("1 + 2 = %d\n", result);
    result = sub(3, 2);
    printf ("3 - 2 = %d\n", result);
    result = mul(3, 2);
    printf ("3 * 2 = %d\n", result);
    result = div(4, 2);
    printf ("4 / 2 = %d\n", result);
    return 0;
}
