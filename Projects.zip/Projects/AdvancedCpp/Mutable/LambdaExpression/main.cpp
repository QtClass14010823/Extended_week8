#include <iostream>

using namespace std;

int main()
{
    int i = 0;
    auto counter = [=]() mutable -> int { return ++i; };
    cout << counter() << endl; // returns 1
    cout << counter() << endl; // returns 2
    cout << counter() << endl; // returns 3
    cout << i << endl; // print 0

    int x = 0;
    auto f1 = [=]() mutable {cout << ++x << endl;};  // OK
    //auto f2 = [=]() {x = 42;};  // Error: a by-value capture cannot be modified in a non-mutable lambda

    f1(); // print 1
    cout << x << endl; // print 0
    f1(); // print 2
    cout << x << endl; // print 0

    return 0;
}
