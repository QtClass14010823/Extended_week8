// C++ code to demonstrate working of
// user defined literals (UDLs)
#include <iostream>
#include <algorithm>
#include <string>

using namespace std;

std::string operator "" _LC(const char* s, std::size_t n)
{
    string str = s;

    std::transform(str.begin(), str.end(), str.begin(),
                          [](unsigned char c){ return std::tolower(c); });

    return str;
}

// Driver code
int main()
{
    string str = "Ali " + "Panahi"_LC;

    cout << str;

    return 0;
}
