#include <iostream>

using namespace std;

constexpr double PI = 3.14159265359;

constexpr double ConvertDegreeToRadian(const double &dDegree)
{
    return (dDegree * (PI / 180));
}

int main()
{
    auto dAngleInRadian = ConvertDegreeToRadian(90.0);
    cout << "Angle in radian: " << dAngleInRadian << endl;
    return 0;
}
