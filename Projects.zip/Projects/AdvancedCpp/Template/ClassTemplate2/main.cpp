// C++ Program to implement
// Use of template
#include <iostream>

using namespace std;

template <class T, class U = double> class A {
    T x;
    U y;

public:
    A() { cout << "Constructor Called" << endl; }
};

int main()
{
    A<char, char> a;
    A<int> b;
    return 0;
}
