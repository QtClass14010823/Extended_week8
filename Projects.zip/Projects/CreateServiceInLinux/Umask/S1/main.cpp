#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main()
{
    int fd;
    mode_t oldmask = umask(S_IRWXG);

    printf("Your old umask is %i\n", oldmask);
    if ((fd = creat("umask.file", S_IRWXU|S_IRWXG)) < 0)
    {
        perror("creat() error");
    }
    else
    {
        system("ls -l umask.file");
        close(fd);
        unlink("umask.file");
    }
    umask(oldmask);

    return 0;
}
