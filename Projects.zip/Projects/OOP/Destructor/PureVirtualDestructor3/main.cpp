// C++ program to demonstrate how a class becomes
// an abstract class when a pure virtual destructor is
// passed

#include <iostream>

class Test {
public:
    virtual ~Test() = 0;
    // Test now becomes abstract class
};
Test::~Test() {}

// Driver Code
int main()
{
    Test p;
    Test* t1 = new Test;
    // [Error] cannot declare variable 'p' to be of abstract type 'Test'
    // [Note] because the following virtual functions are pure within 'Test':
    // [Note] virtual Test::~Test()
    // [Error] cannot allocate an object of abstract type 'Test'
    // [Note] since type 'Test' has pure virtual functions
    return 0;
}
