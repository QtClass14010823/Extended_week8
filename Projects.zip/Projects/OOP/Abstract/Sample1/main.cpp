// An abstract class
class Test
{
    // Data members of class
public:
    // Pure Virtual Function
    virtual void show() = 0;

/* Other members */
};

int main()
{
    return 0;
}
