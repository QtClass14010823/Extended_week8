﻿#include "Form.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form form(QStringList() << "Button1" << "Button2" << "Button3");

    form.show();

    return a.exec();
}
