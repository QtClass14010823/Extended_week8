﻿#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    centeralWgt = new QWidget(this);
    hlay = new QHBoxLayout(centeralWgt);

    btn1 = new CustomButton("Custom Button 1");
    btn2 = new CustomButton("Custom Button 2");
    btn3 = new CustomButton("Custom Button 3");

    hlay->addWidget(btn1);
    hlay->addWidget(btn2);
    hlay->addWidget(btn3);

    setCentralWidget(centeralWgt);
}

MainWindow::~MainWindow()
{
    delete ui;
}
