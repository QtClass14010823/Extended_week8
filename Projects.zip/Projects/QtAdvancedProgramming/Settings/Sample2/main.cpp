﻿#include <QCoreApplication>
#include <QSettings>

#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int i;

    // It is saved in the path of the executable file (In linux and windows)
    QSettings settings("Settings.ini", QSettings::IniFormat);

    i = settings.value("value").toInt();
    cout << "Value is: " << i << endl;

    cout << "Enter new value: ";
    cin >> i;
    settings.setValue("value", i);

    return 0;
}
