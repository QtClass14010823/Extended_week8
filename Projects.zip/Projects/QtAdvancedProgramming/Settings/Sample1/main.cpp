﻿#include <QCoreApplication>
#include <QSettings>

#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int i;

    // Requires admin/root privilege
    // In windows store at "Computer\HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\MyOrg\MyApp" registry
    // In linux store at "/etc/xdg/MyOrg/MyApp.conf" file
    //QSettings settings(QSettings::SystemScope, "MyOrg", "MyApp");

    // Does not require administrative/root privileges
    // In windows store at "Computer\HKEY_CURRENT_USER\Software\MyOrg\MyApp" registry
    // In linux store at "/home/user/.config/MyOrg/MyApp.conf" file
    QSettings settings(QSettings::UserScope, "MyOrg", "MyApp");

    i = settings.value("value").toInt();
    cout << "Value is: " << i << endl;

    cout << "Enter new value: ";
    cin >> i;
    settings.setValue("value", i);

    return 0;
}
